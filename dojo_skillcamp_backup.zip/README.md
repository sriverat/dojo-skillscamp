# Dojo SkillCamp Landing Page

Landing page para Dojo SkillCamp, un programa de formación digital que transforma talento en líderes tecnológicos a través del Modelo de Aceleración de Talento Cíclico (ATC).

## Características

- Diseño moderno y responsive
- Implementado con HTML5 y Tailwind CSS
- Optimizado para SEO
- Accesible
- Alto rendimiento

## Tecnologías Utilizadas

- HTML5
- Tailwind CSS
- Google Fonts (Poppins)
- Optimización de imágenes 